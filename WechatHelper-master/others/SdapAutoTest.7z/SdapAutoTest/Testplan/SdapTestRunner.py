#encoding:utf-8
from Testcore.TestRun import TestRun
if __name__ == '__main__':
    TestRun().TestRun()
    